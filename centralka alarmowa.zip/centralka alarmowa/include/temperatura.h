#ifndef TEMPERATURA_H
#define TEMPERATURA_H




    int temperatura();
    int temperatura_zewn();
    int temperatura_wew();
class temperatura //: public Czujniki
    {

    public:
        temperatura();
        virtual ~temperatura();
    };
class temperatura_zewn: public temperatura
{
    public:
        temperatura_zewn();
        virtual ~temperatura_zewn();
//protected:
        //virtual get(temperatura_zewn(int));

};
class temperatura_wewn: public temperatura
{
     public:
        temperatura_wewn();
        virtual ~temperatura_wewn();
//protected:
        //virtual get(temperatura_wew(int));

};
#endif // TEMPERATURA_H
