#ifndef GAZ_H
#define GAZ_H

char gaz();
class gaz //: public Czujniki
{
    public:
        gaz();
        virtual ~gaz();
    //protected:
        //virtual get(gaz(int));
};

#endif // GAZ_H
