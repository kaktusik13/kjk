#ifndef RUCH_H
#define RUCH_H

char ruch_zewn();
char ruch_wew();
class ruch //: public Czujniki
{
    public:
        ruch();
        virtual ~ruch();
    //protected:
    //virtual get(ruch(int));
};

class ruch_zewn : public ruch
{
    public:
        ruch_zewn();
        virtual ~ruch_zewn();
   // protected:
    //virtual get(ruch_zewn(int));
};

class ruch_wew : public ruch
{
    public:
        ruch_wew();
        virtual ~ruch_wew();
    //protected:
    //virtual get(ruch_wew(int));
};

#endif // RUCH_H
