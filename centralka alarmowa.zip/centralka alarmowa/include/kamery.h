#ifndef KAMERY_H
#define KAMERY_H

char kamery();
char kamery_zewn();
char kamery_wew();

class kamery//: public Czujniki
{
    public:
        kamery();
        virtual ~kamery();
    //protected:

};

class kamery_zewn : public kamery
{
    public:
       kamery_zewn();
       virtual ~kamery_zewn();
    //protected:
};

class kamery_wew: public kamery
{
    public:
        kamery_wew();
        virtual ~kamery_wew();

};

#endif // KAMERY_H
