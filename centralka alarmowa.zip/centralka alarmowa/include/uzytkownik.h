#ifndef UZYTKOWNIK_H
#define UZYTKOWNIK_H


class uzytkownik
{
    string addRight();
        char nazwa_uzytkownika;
        vector <Right> rights;
    public:
        uzytkownik();
        virtual ~uzytkownik();


   // protected:
   // private:
};

#endif // UZYTKOWNIK_H
