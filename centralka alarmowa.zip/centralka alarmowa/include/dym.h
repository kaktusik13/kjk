#ifndef DYM_H
#define DYM_H
char dym();
class dym //: public Czujniki
{
    public:
        dym();
        virtual ~dym();
    //protected:
        //virtual get(dym(char));

};

#endif // DYM_H
