#include <iostream>
#include <cstdio>
#include <iostream>
#include <vector>
#include <list>
#include <temperatura.h>
#include <dym.h>
#include <gaz.h>
#include <ruch.h>
#include <kamery.h>
//#include <uzytkownik.h>


using namespace std;

int data[10];
int godzina[10];
string tresc[100];
string stan();
//char nazwa_uzytkownika();



class Uzytkownik;

class System
{


    public: string wl_alarmu();
    public: string wyl_alarmu();


    //char nazwa_uzytkownika[20];
    string nazwa_uzytkownika;
    vector <Uzytkownik*> Obserwator;

    private:
        char  zmiana_hasla();

         void dodaj_uzytkownika(Uzytkownik* n)
    {
        cin >> nazwa_uzytkownika;
        if (nazwa_uzytkownika = "ADMIN")
        {
            void dodaj_uzytkownika();
        }
        cout << nazwa_uzytkownika << "dodaj uzytkownika " << n -> nazwa_uzytkownika << endl;
    };


     void usun_uzytkownika(Uzytkownik* n)
     {
        cin >> nazwa_uzytkownika;
        if (nazwa_uzytkownika = "ADMIN")
        {
            void usun_uzytkownika();
        }
        cout << "usun uzytkownika" << nazwa_uzytkownika <<  n -> nazwa_uzytkownika << endl;
     };
    public: char odczyt_dziennika_aktywnosci();
};

class Right
{
    public:
    string wl_alarmu();
    string wyl_alarmu();
    //char nazwa_uzytkownika();


    void wyslij_powiadomienie()
    {
        char powiadomienia();
       // vector <user*> ;//itertion:: it;
       /* for (int it = nazwa_uzytkownika.begin; ++it);
        {
            char powiadomienia();
        }*/
        cout<< "data"<< data<< "godzina"<< godzina<< tresc<< endl;
    };
};

class Uzytkownik: public System
{
   public: string addRight();
           char nazwa_uzytkownika;
           vector <Right> rights;

};


class Urzadzenia_peryferyjne : public System
{
    //public: char odczyt_informacji();
    public: int data();
    public: int godzina();
    public: string stan();
};


class Czujniki: public Urzadzenia_peryferyjne

{
    /*get(temperatura_zewn(int), temperatura_wew(int));
    get(dym(char));
    get(ruch_wew(char), ruch_zewn(char));*/


};


class Panel: public Urzadzenia_peryferyjne
{
   string wl_alarmu();
   string wyl_alarmu();

   char  zmiana_hasla();

   char odczyt_dziennika_aktywnosci();
};


int main()
{
    vector <int> temperatura_zewn;
    vector <int>temperatura_wew;
    vector <char> dym;
    vector <char> ruch_wew;
    vector <char> ruch_zewn;
    vector <char> kamery_wew;
    vector <char> kamery_zewn;

    //printf()
    get(temperatura_zewn, temperatura_wew);
    get(dym);
    get(ruch_wew, ruch_zewn);
    get(kamery_zewn, kamery_wew);




    return 0;
}

