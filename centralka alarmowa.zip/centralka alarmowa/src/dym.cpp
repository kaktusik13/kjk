#include "dym.h"

dym::dym()
{
    //ctor
}

dym::~dym()
{
    //dtor
}
