#include "uzytkownik.h"

uzytkownik::uzytkownik()
{
    //ctor
}

uzytkownik::~uzytkownik()
{
    //dtor
}
