#include "gaz.h"

gaz::gaz()
{
    //ctor
}

gaz::~gaz()
{
    //dtor
}
