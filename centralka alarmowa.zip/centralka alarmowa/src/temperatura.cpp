#include "temperatura.h"

temperatura::temperatura()
{
    //ctor
}

temperatura::~temperatura()
{
    //dtor
}
