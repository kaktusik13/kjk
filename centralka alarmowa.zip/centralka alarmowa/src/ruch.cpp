#include "ruch.h"

ruch::ruch()
{
    //ctor
}

ruch::~ruch()
{
    //dtor
}
