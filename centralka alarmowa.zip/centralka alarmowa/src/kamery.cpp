#include "kamery.h"

kamery::kamery()
{
    //ctor
}

kamery::~kamery()
{
    //dtor
}
